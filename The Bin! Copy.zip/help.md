# Weather Station with PIR Sensor and Displays

This project is a simple weather station that uses a variety of sensors and displays to provide weather information and detect human presence in a room. The system integrates a DHT22 sensor for temperature and humidity, a PIR sensor for motion detection, and displays the information on an OLED display and a MAX7219 matrix display.

## Components Used

- **Raspberry Pi Pico W**: Microcontroller for managing sensors and displays.
- **DHT22 Sensor**: Measures temperature and humidity.
- **PIR Motion Sensor**: Detects human presence.
- **Adafruit SSD1306 OLED Display**: Displays weather information.
- **MD_MAX72XX Matrix Display**: Displays motion detection status.
- **Wiring**: Connects all components to the microcontroller.
